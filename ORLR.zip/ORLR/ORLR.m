% DESCRIPTION: This software provides an instance annotation classifier in MIML setting.
% 
% REFERENCES:
% 
% 1. Anh T. Pham, Raviv Raich, and Xiaoli Z. Fern, Dynamic Programming for Instance Annotation in Multi-instance Multi-label Learning. http://arxiv.org/abs/1411.4068
% 2. Anh T. Pham, Raviv Raich, and Xiaoli Z. Fern, Efficient instance annotation in multi-instance learning. SSP 2014
% 3. Anh T. Pham, Raviv Raich, Xiaoli Z. Fern, and Jes�s P�rez Arriaga, Multi-instance multi-label learning in the presence of novel class instances. ICML 2015
% 
% NOTE: This software is free for research propose. For other purposes, please contact Dr. Raviv Raich (raich@eecs.oregonstate.edu).
%
% AUTHOR: Anh T. Pham (ph?m?n{at}eecs.oregonstate.edu //?=a)


function ORLR
folderName=strcat('.\Dataset\LetterFrost\'); file_name='allclasses'; ten_fold_name='letter_frost_10_fold.txt';
option{1}=0; %Regularization, default is 0
option{2}=50; %# of EM iterations, default is 50, or 200 for big datasets
Demo_EMMIL_Synthetic(folderName,file_name,ten_fold_name,'LetterFrost',option);
end




function accuracy=Demo_EMMIL_Synthetic(folderName,file_name,ten_fold_name, ds_name,option)
if(strcmp(ten_fold_name,'')==0)ten_fold_name=strcat(folderName,ten_fold_name);end
 
fullfilename=strcat(folderName,file_name,'.mat');
accuracy=zeros(1,10); 
 
load(fullfilename);clear Data;
 
X=PreprocessingX(X); 

w0=InitializeWeigth(X,Y);

for cross_id=1:10 
    [X_test, y_test, Y_train, X_train]=TrainandTestForrest(ten_fold_name,Y,X,y,10,cross_id);
    accuracy(cross_id)=OneCrossValidation(w0,X_train,Y_train,X_test,y_test,option);
end

dlmwrite(strcat(ds_name,'_','gamma','_',num2str(option{1}),'.txt'),[accuracy mean(accuracy) std(accuracy)]);
end


function accuracy=OneCrossValidation(w0,X_train,Y_train,X_test,y_test,option)
w=ExpectMaximizationMIMIL(w0,X_train,Y_train,option);
accuracy=PredictInductive_Bird(w,X_test,y_test);
end


 
function w=ExpectMaximizationMIMIL(w,X,Y,option)
count=1;
step=1;
 
for i=1:length(X)
    path_in{i}=[]; map_in{i}=[];
end
 
for i=1:length(X)
    shift_table_in{i}=[];
end
 
while(count<=option{2})
for i=1:length(X)
    [p{i}, shift_table_in{i}, path_in{i}, map_in{i}]=ExpectationStep(X{i},Y(i,:),w,shift_table_in{i},path_in{i},map_in{i});
end
 
step=10*step;
[w, step, ~]=MaximizationStep(X,Y,w,p,option{1},step);
count=count+1
end
end
 
 
function [p,shift_table_out,path_out,map_out]=ExpectationStep(X,Y,w,shift_table_in, path_in, map_in)
p=zeros(size(X,2),size(Y,2));
str=PowerSet(Y);
prior=PriorOneBag(X,w);
lastindex=size(X,2);
 
if(isempty(shift_table_in))
    shift_table_out=BuildShiftTable(str);
else
    shift_table_out=shift_table_in;
end
if(isempty(path_in))
    map_out=RememberMap_mex(size(Y,2),str);
    path_out=RememberPath_mex(size(Y,2),str,map_out);
else
    path_out=path_in; map_out=map_in;
end
 
pdynamic_complte_table=DynamicProgramming_mex(lastindex,prior,str,shift_table_out);

Aempty=zeros(size(str,1)-1);Aempty=sparse(Aempty);
class_arr=find(str(size(str,1),:)==1);
for i=1:size(p,1)   
    A=ConstructAMatrix_mex(Aempty,prior(:,i),class_arr',path_out', map_out);A=sparse(A);
    pdynamic=A\pdynamic_complte_table(2:length(pdynamic_complte_table));pdynamic=[0;pdynamic];
    ind=find(pdynamic<0);pdynamic(ind)=0;
    if(lastindex>1)  
        p(i,:)=PosteriorProbability(i,Y,str,prior,pdynamic);
    else
        labels=find(Y(1,:)==1);
        sum_=sum(prior(labels,i));
        for j=1:size(p,2) 
            if(length(find(labels==j))>0)
            p(i,j)=prior(j,i)/sum_;
            end
        end
    end
end
end
 
 
function [w_new, step, enough]=MaximizationStep(X,Y,w,p,gamma,step_init)
grad=Gradient(X,Y,w,p,gamma);
[w_new,step, enough]=BackTracking(w,0.5,0.7,grad,p,X,Y,gamma,step_init);
end
 

function grad=Gradient(X,Y,w,p,gamma)
grad=zeros(size(w,1),size(w,2));
for i=1:size(Y,2)  
    for b=1:length(X)        
      prior=PriorOneBag(X{b},w);prior=prior';
      sum1{b}=X{b}*p{b}(:,i);
      sum2{b}=X{b}*prior(:,i);
    end
    sum1arr=cell2mat(sum1); sum2arr=cell2mat(sum2);
    sum1x=sum(sum1arr,2); sum2x=sum(sum2arr,2);
grad(:,i)= sum1x-sum2x;  
end
 
if(gamma~=0)
grad=grad-gamma*2*w;    
end
 
end
 


function llh_regularization=LoglikelihoodRegularization(X,p,w,gamma)
llh_regularization=Loglikelihood(p,X,w);
if(gamma~=0)
   llh_norm=gamma*trace(w'*w);
   llh_regularization=llh_regularization-llh_norm;
end
end
 
 
 
function [w_new, step, enough]=BackTracking(w,alpha,beta,f1,p,X,Y,gamma,step_init)
stop=0;
enough=0;
f=LoglikelihoodRegularization(X,p,w,gamma);
w0=w;
step=step_init;
while(stop==0)
    w_step=w0+step*f1;
    w_copy=w_step;
    f_w_step=LoglikelihoodRegularization(X,p,w_copy,gamma);
    if(f_w_step>f+alpha*step*trace(f1'*f1))     
            stop=1;
    end
    step=step*beta;
end
w_new=w_step;
end

 
function pout=PosteriorProbability(i,Y,str,prior,pdynamic)
currentsample=i;
possiblelabel=find(Y==1);
p=zeros(size(Y,2),1);
for j=1:length(possiblelabel) 
    strshift=Shift(str,possiblelabel(j),Y);
    sum_=0;
    if(strshift~=-1)
    temp1=pdynamic(size(str,1))+pdynamic(strshift);  
    temp2=prior(possiblelabel(j),currentsample);
    sum_=sum_+temp1*temp2;
    end
    p(possiblelabel(j))=sum_;
end
pout=p/sum(p);
end
 
 
function shift_table=BuildShiftTable(str)
possiblelabel=find(str(size(str,1),:)==1);
shift_table=zeros(size(str,1),length(possiblelabel));
for j=1:length(possiblelabel)
    for i=1:size(str,1)
        shift_table(i,j)=Shift(str,possiblelabel(j), str(i,:));
    end
end
end
 
function strshift=Shift(str,index, currentstr)
tempstr=(str(size(str,1),:)==1);
if(currentstr(index)==1)
currentstr(index)=0;
currentstr=currentstr(tempstr);
d=bi2de_new(flip(currentstr));
strshift=d+1;
else
   strshift=-1;  
end
end
 
function d=bi2de_new(b)
max_length = 1024;
pow2vector = 2.^(0:1:(size(b,2)-1));
size_B = min(max_length,size(b,2));
d = b(:,1:size_B)*pow2vector(:,1:size_B).';
end
 
 
function youtput=PowerSet(yindex)
positivelabelindex=find(yindex==1);
y=zeros(length(positivelabelindex),1);
str=Generate(y,2)-1;
youtput=zeros(size(str,1),size(yindex,2));
for i=1:size(str,1)
    youtput(i,positivelabelindex)=str(i,:);
end
end
 
function str=Generate(y,c)
if (length(y)==1)
    str=zeros(1,c)';
    for i=1:c
        str(i)=i;
    end
else
   half=floor(length(y)/2);
   str1=Generate(y(1:half),c);
   str2=Generate(y(half+1:length(y)),c);
   I1=zeros(size(str2,1),size(str1,1)); M1=[];
   for j=1:size(str1,1)
       I1(:,j)=1;
       M1=cat(1,M1,I1);
       I1(:,j)=0;
   end
   Mstr1=M1*str1;
   I2=eye(size(str2,1)); M2=[];
   for i=1:size(str1,1);
       M2=cat(1,M2,I2);
   end
   Mstr2=M2*str2;
   str=cat(2,Mstr1,Mstr2);
end
end



function llh=Loglikelihood(p,X,w)
llh=zeros(length(X),1);
for b=1:length(X)
    llh(b)=LoglikelihoodOneBag(p{b},X{b},w);
end
llh=sum(llh);
end
 
function llh=LoglikelihoodOneBag(p,X,w)
wX=w'*X;
[wX_max, wX_substract]=SubstractWX(wX);
sum1=sum(sum(p.*(wX)'));
exp_wX=exp(wX_substract);
sum_wX_c=sum(exp_wX);
sum2=sum(log(sum_wX_c));
sum2=sum2+sum(wX_max);
llh=sum1-sum2;
end



 
function accuracy=PredictInductive_Bird(w,X_test,y_test)
score=zeros(length(X_test),1);
total=zeros(length(X_test),1);

for i=1:length(X_test)
    if(size(X_test{i},2)~=0)
        p=PriorOneBag(X_test{i},w);
        [score(i), total(i)]=Eval_Common(y_test{i},p');
    end
end
accuracy=sum(score)/sum(total);
end

 

function w_new=normalize(w)
sum_column=ones(1,size(w,2))./sum(w);
w_new=w*diag(sum_column);
end
 

 
function p=PriorOneBag(X,W)
pro=ExpSubstractOneBag(W,X);
sumpro=sum(pro);
one_=ones(1,length(sumpro));
invsumpro=one_./sumpro;
p=pro*diag(invsumpro);
end
 
function [max_out,wx_out]=SubstractWX(wx_in)
max_out=max(wx_in);
max_out_matrix=ones(size(wx_in,1),1)*max_out;
wx_out=wx_in-max_out_matrix;
end
 
function p=ExpSubstractOneBag(W,X)
wx_in=W'*X;
[wx_max,wx_out]=SubstractWX(wx_in);
p=exp(wx_out);
end
 


function X_out=DataNormalize(X)
 
firstmm=zeros(size(X{1},1),length(X));
secondmm=zeros(size(X{1},1),length(X));
n=0;
 
for i=1:length(X)
    if(size(X{i},2)>0)
        firstmm(:,i)=sum(X{i},2);
        secondmm(:,i)=sum(X{i}.*X{i},2);
        n=n+size(X{i},2);
    end
end
 
mean2=sum(firstmm,2)/n;
 
secondmm2=sum(secondmm,2)/n;
 
variance2=secondmm2-mean2.*mean2;
std2=sqrt(variance2*n/(n-1));
ind=find(std2==0);std2(ind)=abs(mean2(ind))+1;
 
for i=1:length(X)
    if(size(X{i},2)>0)
        for j=1:size(X{i},2)
            temp=X{i}(:,j)-mean2;
            X{i}(:,j)=temp./std2;
        end
    end
end
 
X_out=X;
end


 
function X_out=AddOne(X)
for i=1:length(X)
    X_out{i}=[X{i}; ones(1,size(X{i},2))];
end
end



 
function X_out=PreprocessingX(X)
w = warning ('on','all');
rmpath('folderthatisnotonpath');
warning(w);
id = w.identifier;
warning('off',id);
rmpath('folderthatisnotonpath');
X_out=DataNormalize(X);
X_out=AddOne(X_out);
end
 

 
function [X_test, y_test, Y_train, X_train]=TrainandTest(Y,X,y,ratio,cross)
totalbags=length(X);
sizecross=zeros(1,ratio);
part=floor(totalbags/ratio);
residual=totalbags-part*ratio;
for i=1:length(sizecross)
    sizecross(i)=part;
    if(residual>=1)
    sizecross(i)=sizecross(i)+1;
    residual=residual-1;
    end
end
if(cross<ratio)
    if(cross>1)
        testindex=[sum(sizecross(1:cross-1))+1 : sum(sizecross(1:cross))];
    else
        testindex=[1 : sum(sizecross(1:cross))];
    end
else
    testindex=[sum(sizecross(1:cross-1))+1 : totalbags];    
end
index=zeros(length(X),1);for i=1:length(X)index(i)=i;end
index(testindex)=[];
trainindex=index;
 
Y_train=Y(trainindex,:);
X_test=X(testindex);X_train=X(trainindex);
y_test=y(testindex);
end
 
function [X_test, y_test, Y_train, X_train]=TrainandTestForrest(fullfilename,Y,X,y,ratio,cross)
if(strcmp(fullfilename,'')==0)
    M = csvread(fullfilename);
    testindex=find(M(:,2)==(cross-1));
    index=zeros(length(X),1);for i=1:length(X)index(i)=i;end
    index(testindex)=[];
    trainindex=index; 
    Y_train=Y(trainindex,:);
    X_test=X(testindex);X_train=X(trainindex);
    y_test=y(testindex);
else
    [X_test, y_test, Y_train, X_train]=TrainandTest(Y,X,y,ratio,cross,prunning_index);
end
end
 

function [score, total]=Eval_Common(y,p)
pred=[];
truth=[];
for i=1:size(y,1)
    [valuetruth indtruth]=max(y(i,:));
    [valuepred indpred]=max(p(i,:));
    pred=[pred indpred];
    truth=[truth indtruth];
end
err=abs(pred-truth);
score=length(find(err==0));
total=length(pred);
end
 
 
function w=InitializeWeigth(X,Y) 
w=randi(10,size(X{1},1),size(Y,2));
w=normalize(w);
end
 

 
