+ Run ORLR.m
+ To demo, we provide two datasets: Letter Frost and MSCV2 in the corresponding dataset folders
+ The accuracy should be (around with std) 71% for Letter Frost and 55% for MSCV2, as reported in [1]
+ Dataset format: 
  1. X{b} is an d x n_b matrix denotes n_b instances in the bth bag with d is the feature dimension.
  2. y{b} is an n_b x C matrix denotes corresponding instance labels in the bth bag. C is the number of classes.
     y{b}(i,j)=1 means that the ith instance has label jth. An instance has only one label.
  3. Y is an B x C matrix denotes bag labels of all B bags. Y(b,j)=1 means that the bth bag has label jth. A bag can have multiple labels.
+ Note: Since each instance has one and only one label, please making sure that each bag label Y(b,:) has less or equal labels than the number of instances in X{b}.
+ If you encounter any issue, please contact Anh T. Pham for help

REFERENCES:
[1] Anh T. Pham, Raviv Raich, and Xiaoli Z. Fern, Dynamic Programming for Instance Annotation in Multi-instance Multi-label Learning. IEEE Transactions on PAMI 2017
[2] Anh T. Pham, Raviv Raich, and Xiaoli Z. Fern, Efficient instance annotation in multi-instance learning. SSP 2014
[3] Anh T. Pham, Raviv Raich, Xiaoli Z. Fern, and Jes�s P�rez Arriaga, Multi-instance multi-label learning in the presence of novel class instances. ICML 2015

