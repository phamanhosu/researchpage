function SyntheticDataGeneration
Original_DataGeneration; %Create orginal MIML dataset of 6 classes as follows

VisualizeBags; %Visualize Bags
end


function Original_DataGeneration
%Create orginal MIML dataset of 6 classes
no_og_bags=100;
X=[]; y=[]; 
count=1;
Y=zeros(no_og_bags,4);

% w=randi([-10,10],2,4); w=w/50;
% w=[w; ones(1,4)];

load('w.mat');

X_source=randi([-10,10],2,10000); X_source=[X_source; ones(1,10000)];

y_score=w'*X_source;
[~,y_source]=max(y_score,[],1);


for i=1:no_og_bags
     class_arr=ClassArr(4);   
     [X{count},Y(count,:),y{count}]=BagGeneration(w,class_arr,X_source,y_source);count=count+1;
end

save('Dataset\Synthetic\allclasses\allclasses.mat','X','Y','y');
end





function VisualizeBags
%Visualize Bags
load('Dataset\Synthetic\allclasses\allclasses.mat');

close all;
h=figure;

X=cell2mat(X);
y=cell2mat(y');

PlotData(X,y,10, -10);
end


%%% ===================================Sub-Functions=================================================
function [X_b,Y_b,y_b]=BagGeneration(w,class,X_source,y_source)

X_b=[];
y_b=[];
for i=1:length(class)
    ind=find(y_source==i);
    ind=ind(randperm(length(ind)));
    
    select_ind=ind(1:class(i));
    
    X_b_c=X_source(:,select_ind);
     
    y_b_c=zeros(length(class),class(i));
    if(class(i)~=0)
        y_b_c(i,:)=1;
    end
    
    X_b=[X_b X_b_c];
    y_b=[y_b y_b_c];   
end

X_b=X_b([1:2],:);
y_b=y_b';
Y_b=ptoY(y_b);
end



function class_arr=ClassArr(no_of_class)
a = 1/no_of_class*ones(1,no_of_class);
n = 1;
r = drchrnd(a,n);
class_arr=round(r*10);
end



function r = drchrnd(a,n)
p = length(a);
r = gamrnd(repmat(a,n,1),1,n,p);
r = r ./ repmat(sum(r,2),1,p);
end



function Y=ptoY(p)
Y=zeros(1,size(p,2));
for i=1:size(p,1)
    if(sum(p(i,:))>0)
        [~, indclass]=max(p(i,:));
        Y(indclass)=1;
    end
end
end



function PlotData(X,p,maxx, minx)
color=['b' 'g' 'r' 'c' 'm' 'y' 'k' 'w' 'b' 'g'];
y=zeros(size(X,2),1);

for i=1:size(X,2)
    [value,label]=max(p(i,:));
    y(i)=label;
end

z=unique(y);

for i=1:size(p,2)
    index=find(y==z(i));
    plot(X(1,index),X(2,index),strcat('*',color(z(i))),'MarkerSize',5);
    axis([minx maxx minx maxx]);
    hold on; 
end
end




function [y_in, Y, Y_backup]=IgnoreClass(y_in, class_id)
allclasses=1:1:size(y_in{1},2);
allclasses(class_id)=[];

Y=zeros(length(y_in),size(y_in{1},2)-length(class_id));
Y_backup=zeros(length(y_in),size(y_in{1},2)-length(class_id)+1);

if(length(class_id)~=0)
    for i=1:length(y_in)
       temp=y_in{i}(:,allclasses);
       Y(i,:)=ptoY(temp);

       new_labels_data=UnionClass(y_in{i}(:,class_id));
       temp=[temp new_labels_data];
       y_in{i}=temp;
    end
else
    for i=1:length(y_in)
        Y(i,:)=ptoY(y_in{i});
    end
end

for i=1:length(y_in)
    Y_backup(i,:)=ptoY(y_in{i});
end
end


function newlabels=UnionClass(new_class)
temp=new_class(:,1);
for i=1:size(new_class,2)
    temp=temp+new_class(:,i);
end
newlabels=temp>0;
end



function [X,Y,y,Y_backup]=RemoveEmptyBag(X,Y,y,Y_backup)
delete=[];
for i=1:length(X)
    if(sum(Y(i,:))==0)
       delete=[delete i]; 
    end
end
X(delete)=[];
Y(delete,:)=[];
y(delete)=[];
Y_backup(delete,:)=[];
end



function [X,Y,y,Y_backup]=ShuffleBags(X,Y,y,Y_backup)
rand_perm_id=randperm(size(Y,1),size(Y,1));
X=X(rand_perm_id);
Y=Y(rand_perm_id,:);
y=y(rand_perm_id);
Y_backup=Y_backup(rand_perm_id,:);
end

