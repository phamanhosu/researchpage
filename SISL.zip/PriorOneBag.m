function p=PriorOneBag(X,W)
% pro=exp(W'*X);
pro=ExpSubstractOneBag(W,X);
sumpro=sum(pro);
one_=ones(1,length(sumpro));
invsumpro=one_./sumpro;
p=pro*diag(invsumpro);
end
 

 
function p=ExpSubstractOneBag(W,X)
wx_in=W'*X;
[wx_max,wx_out]=SubstractWX(wx_in);
p=exp(wx_out);
end
 
function [max_out,wx_out]=SubstractWX(wx_in)
max_out=max(wx_in);
max_out_matrix=ones(size(wx_in,1),1)*max_out;
wx_out=wx_in-max_out_matrix;
end