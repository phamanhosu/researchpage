function [w,p,rllharr,llharr]=SingleInstanceSingleLabel(w0,X_train,y_train,iterations,X_test,y_test, option)
[w,p,rllharr,llharr]=SISL_Core(w0,X_train,y_train,iterations,option,option{3});   
end




function [w,p,rllharr,llharr]=SISL_Core(w,X,y,SISLiterations,option,gamma)
[X,y]= ConvertSISLtoMIMIL(X,y);
[w,p,rllharr,llharr]=MaximizationSISL(w,X,y,SISLiterations,option,gamma);
end
 
 
function [X_out, y_out]= ConvertSISLtoMIMIL(X,y)
X_out{1}=cell2mat(X);
y_out{1}=cell2mat(y');
end
 

function [w_new, step, enough]=MaximizationStep(X,w,p,option,gamma,step_init)
w_new=zeros(size(w,1),size(w,2));
prior=PriorAllBag(X,w);
 
if(strcmp(option,'newton')==1)
HessianMatrix=HessianMatrixAllBag(X,prior,w,gamma);
end
 
grad=Gradient(X,w,p,gamma);
 
% [substract_grad,appro_grad]=CheckGrad(grad,X,w,p,6,gamma);
% [substract_hessi,appro_hessi]=CheckHessian(HessianMatrix,X,w,p,4,gamma);
 
if(strcmp(option,'newton')==1)
[w_new,step, enough]=BackTracking_newton(w,0.5,0.7,grad,HessianMatrix,p,X,gamma);
elseif(strcmp(option,'gradient')==1)
[w_new,step, enough]=BackTracking_gradient(w,0.5,0.7,grad,p,X,gamma,step_init);
end

end



 
%% Backtracking section
 
function grad=Gradient(X,w,p,gamma)
grad=zeros(size(w,1),size(w,2));
for i=1:size(w,2)  
    for b=1:length(X)        
      prior=PriorOneBag(X{b},w);prior=prior';
      sum1{b}=X{b}*p{b}(:,i);
      sum2{b}=X{b}*prior(:,i);
    end
    sum1arr=cell2mat(sum1); sum2arr=cell2mat(sum2);
    sum1x=sum(sum1arr,2); sum2x=sum(sum2arr,2);
grad(:,i)= sum1x-sum2x;  
end
 
w_temp=w;
grad=grad-gamma*2*w_temp;   
end
 

 
function llh_regularization=LoglikelihoodRegularization(X,p,w,gamma)
llh_regularization=Loglikelihood(p,X,w);
llh_norm=gamma*trace(w'*w);
llh_regularization=llh_regularization-llh_norm;
end
 


 
function H=HessianMatrixAllBag(X,p,w,gamma)
H=zeros(size(X{1},1)*size(w,2));
for i=1:length(X)
    temp=HessianMatrixOneBag(X{i},w,p{i});
    H=H+temp;
end
H=H-2*gamma*eye(size(H));
end


 
function H=HessianMatrixOneBag(X,Y,p)
for i=1:size(X,2)
    XX{i}=X(:,i)*X(:,i)';
end
H=zeros(size(X,1)*size(Y,2));
for i=1:size(Y,2)
    for j=1:size(Y,2)
        M=zeros(size(X,1));
        for k=1:size(X,2)
            if(i==j)
                M=M+p(k,i)*XX{k}-p(k,i)*p(k,i)*XX{k};
            else
                M=M-p(k,i)*p(k,j)*XX{k};
            end           
        end
        H=UpdateBlock(H,M,i,j,size(X,1));
    end
end
H=-H;
end


 
function [substract,approdiff]=CheckGrad(f1,X,w,p,precise,gamma)
 
llh=LoglikelihoodRegularization(X,p,w,gamma);
substract=zeros(size(w,1),size(w,2));
approdiff=zeros(size(w,1),size(w,2));
for i=1:size(w,2)
    for j=1:size(w,1)
        temp=zeros(size(w,1),size(w,2));
        temp(j,i)=power(10,-precise);
        w_test=w+temp;
        llh_temp=LoglikelihoodRegularization(X,p,w_test,gamma);     
        diff=llh_temp-llh;
 
        approdiff(j,i)=diff*power(10,precise);
        substract(j,i)=f1(j,i)-approdiff(j,i);
    end
end
 
end
 
function [substract,approhessi]=CheckHessian(Hessian,X,w,p,precise,gamma)
 
grad=Gradient(X,w,p,gamma);
substract=zeros(size(X{1},1)*size(w,2));
approhessi=zeros(size(X{1},1)*size(w,2));
 
for i=1:size(w,2)
    for j=1:size(w,1)
        temp=zeros(size(w,1),size(w,2));
        temp(j,i)=power(10,-precise);
        w_test=w+temp;
        grad_temp=Gradient(X,w_test,p,gamma);
        diff=grad_temp-grad;
        diff=MatrixToColumn(diff);
        approhessi((i-1)*size(w,1)+j,:)=diff'*power(10,precise);
        substract((i-1)*size(w,1)+j,:)=Hessian((i-1)*size(w,1)+j,:)-approhessi((i-1)*size(w,1)+j,:);
    end
end
end


 
function [w_index_new, step, enough]=BackTracking_newton(w,alpha,beta,f1,HessianMatrix,p,X,gamma)
stop=0;
enough=0;
f1=MatrixToColumn(f1);f1=f1';
tempvector=pinv(HessianMatrix)*f1;
f=LoglikelihoodRegularization(X,p,w,gamma);
w0=w;
step=1;
while(stop==0)
    w_step=w0-ColumnToMatrix(step*tempvector,size(w,1));
    w_copy=w_step;
    f_w_step=LoglikelihoodRegularization(X,p,w_copy,gamma);
    f_boud=f-alpha*step*(f1'*tempvector);
    if(f_w_step>f_boud)
        stop=1;
    end
    step=step*beta;
    if ((step<1e-12)&&(f_w_step>=f))
        stop=1;
        enough=1;
    end
end
w_index_new=w_step;
end
 


function [w_new, step, enough]=BackTracking_gradient(w,alpha,beta,f1,p,X,gamma,step_init)
stop=0;
enough=0;
f=LoglikelihoodRegularization(X,p,w,gamma);
w0=w;
step=step_init;
while(stop==0)
    w_step=w0+step*f1;
    w_copy=w_step;
    f_w_step=LoglikelihoodRegularization(X,p,w_copy,gamma);
    if(f_w_step>f+alpha*step*trace(f1'*f1))     
            stop=1;
    end
    step=step*beta;
    if ((step<1e-12)&&(f_w_step>=f))
        stop=1;
        enough=1;
    end
    if (step<1e-20)
        stop=1;
        enough=1;
    end
end
w_new=w_step;
end
%% Backtracking section
 

 
%% Likelihood section
function llh=Loglikelihood(p,X,w)
llh=zeros(length(X),1);
for b=1:length(X)
    llh(b)=LoglikelihoodOneBag(p{b},X{b},w);
end
llh=sum(llh);
end


 
function llh=LoglikelihoodOneBag(p,X,w)
wX=w'*X;
[wX_max, wX_substract]=SubstractWX(wX);
sum1=sum(sum(p.*(wX)'));
exp_wX=exp(wX_substract);
sum_wX_c=sum(exp_wX);
sum2=sum(log(sum_wX_c));
sum2=sum2+sum(wX_max);
llh=sum1-sum2;
end


function [max_out,wx_out]=SubstractWX(wx_in)
max_out=max(wx_in);
max_out_matrix=ones(size(wx_in,1),1)*max_out;
wx_out=wx_in-max_out_matrix;
end
 
%% SISL section 
function [w,p,rllharr,llharr]=MaximizationSISL(w,X,y,iterations,option,gamma)
count=1;
step=1;
llharr=zeros(1,iterations);

while(count<=iterations)
llharr(count)=LoglikelihoodRegularization(X,y,w,gamma);    
step=step*10;
[w, step, enough]=MaximizationStep(X,w,y,option{4},gamma,step);
if(enough==1)
    break;
end
count=count+1
end
p=y;
rllharr=llharr;
end
%% SISL section

 
%% Predicting section
 



 
%% Utility section
 
%---w---

%---probability---
function p=PriorAllBag(X,w)
for i=1:length(X)
        p{i}=PriorOneBag(X{i},w);
        p{i}=p{i}';
end
end
 

%---Matrix---

function column=MatrixToColumn(M)
column=reshape(M,1,size(M,1)*size(M,2));
end
 
function matrix=ColumnToMatrix(col,d)
column=length(col)/d;
matrix=zeros(d,column);
for i=1:column
    matrix(:,i)=col((i-1)*d+1:i*d);
end
end
 
function Mout=UpdateBlock(Min,Block,i,j,d)
column_left=(j-1)*d+1;
column_right=j*d;
row_up=(i-1)*d+1;
row_down=i*d;
Min(row_up:row_down,column_left:column_right)=Block;
Mout=Min;
end
 
%---Train and Test---

 



