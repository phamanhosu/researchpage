function SISL_Toy
folder_name=strcat('Dataset'); file_name='allclasses'; ten_fold_name=''; ds_name='Synthetic'; gamma=0;
interations=50;

if(strcmp(ten_fold_name,'')==0);ten_fold_name=strcat(folder_name,'\',ds_name,'\','allclasses','\',ten_fold_name);end
 
fullfilename=strcat(folder_name,'\',ds_name,'\','allclasses','\',file_name,'.mat'); 
parameter_array={'gradient',interations,gamma,'gradient'}; 

load(fullfilename);clear Data;

minx=-10; maxx=10; [X, ~]=AddBoundBag(X,minx,maxx,100); X_bound_data=X{length(X)}; X_data=X(1:length(X)-1); 
 
X=PreprocessingX(X); 
X_bound_feature=X{length(X)}; X_data_feature=X(1:length(X)-1);
X=X_data_feature; 

w0=LoadExistFile(X,Y);

[w,~,~,~]=SingleInstanceSingleLabel(w0,X,y,interations,X,y, parameter_array);

PlotResultBoundary(X_bound_feature,X_bound_data,maxx, minx, w);

PlotOriginalDistribution;
end



function PlotOriginalDistribution
load('Dataset\Synthetic\allclasses\allclasses.mat');
h=figure;

X=cell2mat(X);
y=cell2mat(y');

PlotData(X,y,10, -10);
end





function [X, X_bound]=AddBoundBag(X,minx,maxx,resolution)
u = linspace(minx,maxx, resolution);
v = linspace(minx, maxx, resolution);
X_bound=[];
for i = 1:length(u)
    for j = 1:length(v)
        X_bound=[X_bound [u(i) v(j)]'];
    end
end
X{length(X)+1}=X_bound;
end




function PlotResultBoundary(X_bound,X_bound_data,maxx, minx, w)
p=PriorOneBag(X_bound,w); p=p';
PlotData(X_bound_data,p,maxx, minx);
end




function PlotData(X,p,maxx, minx)
color=['b' 'g' 'r' 'c' 'm' 'y' 'k' 'w' 'b' 'g'];
y=zeros(size(X,2),1);

for i=1:size(X,2)
    [value,label]=max(p(i,:));
    y(i)=label;
end

z=unique(y);

for i=1:length(z)
    index=find(y==z(i));
    plot(X(1,index),X(2,index),strcat('.',color(z(i))),'MarkerSize',20);
    axis([minx maxx minx maxx]);
    hold on; 
end
end




function w_new=normalize(w)
sum_column=ones(1,size(w,2))./sum(w);
w_new=w*diag(sum_column);
end
 


function w=Initializew(X,Y)
w=randi(10,size(X{1},1),size(Y,2));
end
 


function X_out=DataNormalize(X)
 
firstmm=zeros(size(X{1},1),length(X));
secondmm=zeros(size(X{1},1),length(X));
n=0;
 
for i=1:length(X)
    if(size(X{i},2)>0)
        firstmm(:,i)=sum(X{i},2);
        secondmm(:,i)=sum(X{i}.*X{i},2);
        n=n+size(X{i},2);
    end
end
 
mean2=sum(firstmm,2)/n;
 
secondmm2=sum(secondmm,2)/n;
 
variance2=secondmm2-mean2.*mean2;
std2=sqrt(variance2*n/(n-1));
ind=find(std2==0);std2(ind)=abs(mean2(ind))+1;
 
for i=1:length(X)
    if(size(X{i},2)>0)
        for j=1:size(X{i},2)
            temp=X{i}(:,j)-mean2;
            X{i}(:,j)=temp./std2;
        end
    end
end
 
X_out=X;
end


 
function X_out=AddOne(X)
for i=1:length(X)
    X_out{i}=[X{i}; ones(1,size(X{i},2))];
end
end


 
function X_out=PreprocessingX(X)
w = warning ('on','all');
rmpath('folderthatisnotonpath');
warning(w);
id = w.identifier;
warning('off',id);
rmpath('folderthatisnotonpath');

X_out=DataNormalize(X);
X_out=AddOne(X_out);
end


 
function w=LoadExistFile(X,Y)
w0=Initializew(X,Y); %save('w0.mat','w0');
% load('w0.mat');
w=w0;
w=normalize(w);
end

%% Utility section